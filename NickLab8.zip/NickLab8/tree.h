#pragma once

#include <iostream>
#include <fstream>
using namespace std;

//-----------------------------------------------------------
// BinaryTree data node definition
//-----------------------------------------------------------
class Node
{
public:
	char Value;
	Node *Left;
	Node *Right;
};


//-----------------------------------------------------------
// Define the BinaryTree class interface 
//-----------------------------------------------------------
class BinaryTree
{
public:
	// Constructor functions
	BinaryTree();
	BinaryTree(char *Name);
	~BinaryTree();

	// General binary tree operations
	bool Search(int Value);
	bool Insert(int Value);
	void Delete(int Value);
	void Print();

private:
	bool SearchNode(Node * Tree, char Value);
	bool InsertNode(Node * &Tree, char Value);
	void PrintNode(Node * Tree);
	void PrintPost(Node * Tree);
	void PrintPre(Node * Tree);
	int getCount(Node * Tree);

	void DestroyNode(Node * Tree); //for Destructor

								   // Tree pointer
	Node *Root;
};
