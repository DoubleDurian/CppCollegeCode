#include "tree.h"
#include <iostream>

// ---------------------------------------------------------- -
// Main program tests the BinaryTree class.
//-----------------------------------------------------------
int main()
{
	BinaryTree Tree;
	Tree.Insert('j');
	Tree.Insert('e');
	Tree.Insert('f');
	Tree.Insert('t');
	Tree.Insert('a');
	Tree.Insert('m');
	Tree.Insert('v');
	cout << "Printing the sequence in INORDER followed by POSTORDER then by PREORDER" << endl;
	Tree.Print();
	cout << "Deleting the V character from the sequence and reprinting in the same order" << endl;
	Tree.Delete('v');
	Tree.Print();
	
	if (Tree.Search('e')) cout << "Search  e found\n";
	system("pause");
	return 0;
}
