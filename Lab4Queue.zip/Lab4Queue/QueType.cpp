// Implementation file for Queue ADT; class specification in file Queue2.h.
// Class is templated.
// Uses linked list of items with a pointer to the head and one to the tail.

#include <cstddef>		 	// For NULL
#include "queType.h"
#include <iostream>
using namespace std;
QueType::QueType()	// Class constructor.
					// Post:  qFront and qRear are set to NULL.
{
	qFront = NULL;
	qRear = NULL;
}

void QueType::MakeEmpty()  // Post: Queue is empty; all elements have been deallocated.
{
	NodeType* tempPtr;

	while (qFront != NULL)
	{
		tempPtr = qFront;
		qFront = qFront->next;
		delete tempPtr;
	}
	qRear = NULL;
}

QueType::~QueType()
{
	MakeEmpty();
}

bool QueType::IsFull() const
// Returns true if there is no room for another ItemType on the free store;
// false otherwise.
{
	NodeType * ptr;
	ptr = new NodeType;
	if (ptr == NULL)
		return true;
	else
	{
		delete ptr;
		return false;
	}
}


bool QueType::IsEmpty() const
// Returns true if there are no elements on the queue; false otherwise.
{
	return (qFront == NULL);
}

void QueType::Enqueue(ItemType newItem)
// Adds newItem to the rear of the queue.
// Pre:  Queue has been initialized and is not full.
// Post: newItem is at rear of queue.

{

	if (IsFull())
		throw FullQueue();
	else
	{
		NodeType* newNode;
		newNode = new NodeType;
		newNode->info = newItem;
		newNode->next = NULL;
		if (qRear == NULL)
			qFront = newNode;
		else
			qRear->next = newNode;
		qRear = newNode;
	}
}


void QueType::Dequeue(ItemType& item)
// Removes front item from the queue and returns it in item.
// Pre:  Queue has been initialized and is not empty.
// Post: Front element has been removed from queue.
//       item is a copy of removed element.
{

	if (IsEmpty())
	{
		cout << "Could not remove element from queue, the queue is empty!" << endl;
		item = NULL;
		//throw EmptyQueue();
	}		
	else
	{
		NodeType* tempPtr;

		tempPtr = qFront;
		item = qFront->info;
		qFront = qFront->next;
		if (qFront == NULL)
			qRear = NULL;
		delete tempPtr;
	}
}
