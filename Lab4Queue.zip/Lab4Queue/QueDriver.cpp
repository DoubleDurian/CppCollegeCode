#include <iostream>
#include <fstream>
#include <string>
#include "QueType.h"
using namespace std;
int main()
{
	ifstream inFile;
	ofstream outFile;
	string infileName;
	string outfileName;
	string outputLable;
	string command;
	QueType* myQue = new QueType();
	//int numberOfCommands;
	int number;
	cout << "Enter name of input file; press return." << endl;
	cin >> infileName;
	inFile.open(infileName.c_str());

	cout << "Enter name of output file; press return." << endl;
	cin >> outfileName;
	outFile.open(outfileName.c_str());

	inFile >> command;
	while (command != "Quit")
	{
		if (command == "Enqueue")
		{
			if (!myQue->IsFull())
			{
				inFile >> number;
				cout << command << " ";
				cout << number << endl;
				myQue->Enqueue(number);
			}
			
		}
		else if (command == "Dequeue")
		{
			if (!myQue->IsEmpty())
			{
				myQue->Dequeue(number);
				cout << "The number " << number << " was dequeued" << endl;
				outFile << number;
			}
			else
			{
				cout << "Error the Que is empty, therefore no number could be removed from it." << endl;
			}
			

			//cout << command;
		}
		else if (command == "IsFull")
		{
			//cout << command;
			myQue->IsFull();
		}
		else if (command == "IsEmpty")
		{
			//cout << command;
			myQue->IsEmpty();
		}
		inFile >> command;
	}

	system("pause");
	return 0;
}