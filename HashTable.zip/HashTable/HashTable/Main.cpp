
//CMPSC125     Spring 2016    
//
//Project:  Extra Credit
//
// Author:    Nick Johnston
//
// File Name: Main.cpp
//
// Date:  5/8/2016
//
// Description: This creates a hash map of the thing
#include "HashTable.h"

int main()
{
	// Create 26 Items to store in the Hash Table.
	Item * A = new Item{ "Cooking with Snails Vol I, Nicholas Johnston, Canadian Press, 1995", NULL };
	Item * B = new Item{ "Cooking with Snails Vol II, Barack Obama, Canadian Press 1996", NULL };
	Item * C = new Item{ "The Saga of the Hash Array, Gary Coleman, Penguine Books, 2007", NULL };
	Item * D = new Item{ "Elvis isn't dead, Elvish Presley, Elvis Prints, 2040", NULL };
	Item * E = new Item{ "List and how to code them, Nicholas Johnston, Canada Press, 2013", NULL };
	Item * F = new Item{ "Cooking with Snails Vol III, Barack Obama, Canadian Press 1996", NULL };
	Item * G = new Item{ "Cooking with Snails Vol IV, Barack Obama, Canadian Press 1996", NULL };
	Item * H = new Item{ "Atomic theory, Barack Obama, Canadian Press 1996", NULL };
	Item * I = new Item{ "How to fish with worms,Doug Oppenhiemer, Canadian Press 1996", NULL };
	Item * J = new Item{ "Taiwan not real china, china, China, 1996", NULL };
	Item * K = new Item{ "electric avinue,Frenchmen Bonjur, Canadian Press 1996", NULL };
	Item * L = new Item{ "Welcome to the Danger Zone, Bill Mury, Canadian Press 1996", NULL };
	Item * M = new Item{ "Notepads and where to find them, Gary Coleman, Canadian Press 1996", NULL };
	Item * N = new Item{ "HELP! Im trapped in an infite time loop,Gary Coleman, Canadian Press 3100", NULL };
	Item * O = new Item{ "Math, DaaVinci, Canadian Press 1996", NULL };
	Item * P = new Item{ "The Joy of Tarro Cards, Dio Brando, Za World Press, 1996", NULL };
	Item * Q = new Item{ "Road Rollers: A personal fear, Jotaro Kujo, Speedwagon prints, 1996", NULL };
	Item * R = new Item{ "Krabby Patty Fromula,Plankton, Chum pages, 1990", NULL };
	Item * S = new Item{ "Ravioli Ravioli, Gabe formuoli, Canadian Press, 1996", NULL };
	Item * T = new Item{ "Acheology for Aztecs, DIO, Canadian Press, 1996", NULL };
	Item * U = new Item{ "Flags of the World, Diago Joestar, Canadian Press, 1996", NULL };
	Item * V = new Item{ "What is love, Dio Brando, Canadian Press, 1996", NULL };
	Item * W = new Item{ "Harry Potter, Dio Brando, Canadian Press, 1996", NULL };
	Item * X = new Item{ "Twilight, Dio Brando, Canadian Press, 1996", NULL };
	Item * Y = new Item{ "engrish, Dio Brando, Canadian Press, 1996", NULL };
	Item * Z = new Item{ "Sushi is good, Dio Brando, Canadian Press, 1996", NULL };
	Item * more = new Item{ "Kimchi is better, Dio Brando, Canadian Press, 1996", NULL };
	Item * one = new Item{ "The Book, Dio Brando, Canadian Press, 1996", NULL };
	Item * two = new Item{ "Title, DIO, Press, 1996", NULL };
	Item * three = new Item{ "Interesting, Dio Brando, Canadian Press, 1996", NULL };
	// Create a Hash Table of 13 Linked List elements.
	HashTable table;

	
	table.insertItem(A);
	table.insertItem(B);
	table.insertItem(C);
	//table.printTable();
	//table.printHistogram();

	
	//table.printTable();
	//table.printHistogram();


	
	table.insertItem(D);
	table.insertItem(E);
	table.insertItem(F);
	table.insertItem(G);
	table.insertItem(H);
	table.insertItem(I);
	table.insertItem(J);
	table.insertItem(K);
	table.insertItem(L);
	table.insertItem(M);
	table.insertItem(N);
	table.insertItem(O);
	table.insertItem(P);
	table.insertItem(Q);
	table.insertItem(R);
	table.insertItem(S);
	table.insertItem(T);
	table.insertItem(U);
	table.insertItem(V);
	table.insertItem(W);
	table.insertItem(X);
	table.insertItem(Y);
	table.insertItem(Z);
	table.insertItem(more);
	table.insertItem(one);
	table.insertItem(two);
	table.insertItem(three);
	table.printTable();
	table.printHistogram();

	
	
	system("pause");
	
	return 0;
}