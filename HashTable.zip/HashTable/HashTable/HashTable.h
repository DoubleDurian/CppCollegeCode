#ifndef HashTable_h
#define HashTable_h

#include "LinkedList.h"


class HashTable
{
private:


	LinkedList * array;

	int length;


	int hash(string itemKey);

public:


	HashTable(int tableLength = 7);


	void insertItem(Item * newItem);


	bool removeItem(string itemKey);


	Item * getItemByKey(string itemKey);

	void modifyItem(string itemKey, Item * newItem);

	
	void printTable();

	
	void printHistogram();

	
	int getLength();

	
	int getNumberOfItems();

	
	~HashTable();
};

#endif