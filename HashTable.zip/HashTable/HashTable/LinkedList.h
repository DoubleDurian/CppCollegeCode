
#ifndef LinkedList_h
#define LinkedList_h

#include <iostream>
#include <string>
using namespace std;


struct Item
{
	string key;
	Item * next;
};

class LinkedList
{
private:
	
	Item * head;


	int length;

public:
	
	LinkedList();

	
	void insertItem(Item * newItem);

	
	bool removeItem(string itemKey);


	Item * getItem(string itemKey);

	void modify(string itemKey, Item * newItem);


	void printList();


	int getLength();


	~LinkedList();
};

#endif
