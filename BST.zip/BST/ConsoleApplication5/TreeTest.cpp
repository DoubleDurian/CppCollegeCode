#include "tree.h"
#include <iostream>

// ---------------------------------------------------------- -
// Main program tests the BinaryTree class.
//-----------------------------------------------------------
int main()
{
	BinaryTree Tree;
	Tree.Insert('j');
	Tree.Insert('e');
	Tree.Insert('f');
	Tree.Insert('t');
	Tree.Insert('a');
	Tree.Insert('m');
	Tree.Insert('v');
	Tree.Print();
	
	Tree.Delete('t');
	Tree.Print();
	
	if (Tree.Search('e')) cout << "Search  e found\n";
	return 0;
}

