#include "tree.h"
#include <stdlib.h>


void GetPredecessor(Node* tree, int& data);
void DeleteNode(Node*& Tree);
void DeleteNode(Node*& Tree, int value);

//-----------------------------------------------------------
// Constructor function.
//-----------------------------------------------------------
BinaryTree::BinaryTree()
{
	Root = NULL;
}

//-----------------------------------------------------------
// Constructor function that reads tree from file.
//-----------------------------------------------------------
BinaryTree::BinaryTree(char *Name)
{
	Root = NULL;

	// Open input file
	ifstream din;
	din.open(Name);
	if (din.fail())
		cout << "Error: could not open input file\n";

	// Read the data
	int Value;
	din >> Value;
	while (!din.eof())
	{
		InsertNode(Root, Value);
		din >> Value;
	}

	// Close the file
	din.close();
}


//-----------------------------------------------------------
// Destructor function Node function.
//-----------------------------------------------------------
void BinaryTree::DestroyNode(Node * Tree)
{
	// Delete node and it's children
	if (Tree != NULL)
	{
		DestroyNode(Tree->Left);
		DestroyNode(Tree->Right);
		delete Tree;
	}
}

//-----------------------------------------------------------
// Destructor function.
//-----------------------------------------------------------
BinaryTree::~BinaryTree()
{
	// Call tree destroy function
	DestroyNode(Root);
}

//-----------------------------------------------------------
// Search Node function.
//-----------------------------------------------------------
bool BinaryTree::SearchNode(Node * Tree, char Value)
{
	// Data value not found 
	if (Tree == NULL)
		return false;

	// Data value found 
	else if (Tree->Value == Value)
		return true;

	// Recursively search for data value
	else if (Tree->Value > Value)
		return (SearchNode(Tree->Left, Value));
	else if (Tree->Value < Value)
		return (SearchNode(Tree->Right, Value));
	else
		return false;
}

//-----------------------------------------------------------
// Search for data in the binary tree.
//-----------------------------------------------------------
bool BinaryTree::Search(int Value)
{
	// Call tree searching function
	return (SearchNode(Root,Value));
}

//-----------------------------------------------------------
// Insert Node function.
//-----------------------------------------------------------
bool BinaryTree::InsertNode(Node * &Tree, char Value)
{
	// Insert data into the tree
	if (Tree == NULL)
	{
		Tree = new Node;
		Tree->Value = Value;
		Tree->Left = NULL;
		Tree->Right = NULL;
		return true;
	}

	// Recursively search for insertion position
	else if (Tree->Value > Value)
		return (InsertNode(Tree->Left, Value ));
	else
		return (InsertNode(Tree->Right, Value));
}

//-----------------------------------------------------------
// Insert data into the binary tree.
//-----------------------------------------------------------
bool BinaryTree::Insert(int Value)
{
	// Call tree insertion function
	return (InsertNode(Root, Value));
}

//-----------------------------------------------------------
// Print Node function.  inorder 
//-----------------------------------------------------------
void BinaryTree::PrintNode(Node * Tree)
{
	// Check terminating condition
	if (Tree != NULL)
	{
		// Print left subtree
		
		PrintNode(Tree->Left);

		// Print node value
		cout << " " << Tree->Value << " ";

		// Print right subtree
		PrintNode(Tree->Right);
		
	}
}



//-----------------------------------------------------------
// Print all records in the binary tree.
//-----------------------------------------------------------
void BinaryTree::Print()
{
	// Call tree printing function
	PrintNode(Root);
	cout << endl;
}


void BinaryTree::Delete(int value)
{
	DeleteNode(Root, value);
}


void DeleteNode(Node*& Tree, int value)
{
	if (value < Tree->Value)
		DeleteNode(Tree->Left, value);   // Look in left subtree.
	else if (value > Tree->Value)
		DeleteNode(Tree->Right, value);  // Look in right subtree.
	else
		DeleteNode(Tree);           // Node found; call DeleteNode.
}


void DeleteNode(Node*& Tree)
{
	int data;
	 Node* tempPtr;

	tempPtr = Tree;
	if (Tree->Left == NULL)
	{
		Tree = Tree->Right;
		delete tempPtr;
	}
	else if (Tree->Right == NULL)
	{
		Tree = Tree->Left;
		delete tempPtr;
	}
	else
	{
		GetPredecessor(Tree->Left, data);
		Tree->Value = data;
		DeleteNode(Tree->Left, data);  // Delete predecessor node.
	}
}



void GetPredecessor(Node* Tree, int& data)
// Sets data to the info member of the right-most node in tree.
{
	while (Tree->Right != NULL)
		Tree = Tree->Right;
	data = Tree->Value;
}

