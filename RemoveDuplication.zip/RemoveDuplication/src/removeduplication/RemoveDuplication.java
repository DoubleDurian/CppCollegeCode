/*
 * Program:RemoveDuplication
 * This:RemoveDuplication.java
 * Date:2/13/2016
 * Author:Nicholas Johnston
 * Purpose:To remove duplicates in an ArrayList
 */
package removeduplication;

import java.util.ArrayList;
import java.util.Scanner;


public class RemoveDuplication {


    public static void main(String[] args) 
    {
        /* Debugging block
        ArrayList<String> placesToSee = new ArrayList<String>();
        placesToSee.add("Canada");
        placesToSee.add("Canada");
        placesToSee.add("Canada");
        placesToSee.add("Thailand");
        placesToSee.add("Indonesia");
        placesToSee.add("Vermont");
        placesToSee.add("North Korea");
        placesToSee.add("Thunder Dome");
        placesToSee = removeDuplicates(placesToSee);
        for(int i =0; i< placesToSee.size(); i++)
        {
           System.out.println(placesToSee.get(i));
        }
        */
        Scanner scan = new Scanner(System.in);
        int numberOfElements;
        System.out.println("Enter the number of elements you will "
                + "be adding to this"
                + "ArrayList Object");
        ArrayList<String> list = new ArrayList<String>();
        
        while(!scan.hasNextInt())
        {
            scan.nextLine();
            System.out.println("Please re-enter an integer value");
            
            
        }
        numberOfElements = scan.nextInt();
        for(int i = 0; i< numberOfElements;i++)
        {
            System.out.println("Please enter a line of text to the next film");
            list.add(scan.next());
        }
        System.out.println("\n\n");
        list = removeDuplicates(list);
        for(int i =0;i<list.size();i++)
        {
            System.out.println(list.get(i));
        }
        
        
        
        
        
    }
    public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list)
    {//This method adds the element of list at index i into newList
        //but only if the newList does not contain that element already
        //It then returns the the newList 
        ArrayList<E> newList = new ArrayList<E>();
        
        
        for(int i =0;i<list.size();i++)
        {
            if(!newList.contains(list.get(i)))
            {
                newList.add(list.get(i));
            }
        }
        return newList;
    }
    
}
