#include<iostream>
using namespace std;
void Hanoi(int diskSize,int source, int destination, int spare)
{
	if (diskSize == 1)
	{
		cout << "Move disk " << diskSize << " from " << source <<" to " << destination << endl;
	}
	else
	{
		Hanoi(diskSize - 1, source, spare, destination);
		cout << "Move disk " << diskSize << " from " << source << " to " << destination << endl;
		Hanoi(diskSize - 1, spare, destination, source);
	}
	
}
int main()
{
	Hanoi(4, 1, 3, 2);
	system("pause");
	return 0;
}