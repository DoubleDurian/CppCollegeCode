/*
 * Program:SortedArrayListDriver
 * This:IntegerLog.java
 * Date:2/27/2016
 * Author:Nicholas Johnston
 * Purpose:To hold the node objects in a log
 */
package sortedarraylistdriver;
import java.util.Arrays;
public class IntegerLog 
{
    protected LLNode log; //reference to first node of the list
    protected String name; //name of String Log
    
    //==================constructor============================================
    public IntegerLog(String name)
    {
        log = null;
        this.name = name;
    }
    //=====================void insert()========================================
    public void insert(int element)
    {
        LLNode newNode = new LLNode(element);
        newNode.setLink(log);
        log = newNode;
    }
    // ================boolean isFull()=========================================
    public boolean isFull()
    {
        return false;
    }
    //=====================int size()===========================================
    public int size()
    {
        int count =0;
        LLNode node;
        node = log;
        while(node != null)
        {
            count++;
            node = node.getLink();
        }
        return count;
    }
    //====================void clear()==========================================
    public void clear()
    {
        log = null;
    }
    //======================String getName()====================================
    public String getName()
    {
        return name;
    }
    //=====================String toString()====================================
    public String toString()
    {
        String logString = "Log: " + name + "\n\n";
        LLNode node;
        node = log;
        int count = 0;
        
        while(node != null)
        {
            count++;
            logString = logString + count + ". " + node.getInfo()
                    + "\n";
            node = node.getLink();
        }
        return logString;
    }
    //=====================boolean contains()===================================
    public boolean contains(int element)
    {
        LLNode node;
        node = log;
        
        while(node != null)
        {
            if(element == node.getInfo())
            {
                return true;
            }
            else
            {
                node = node.getLink();
            }
        }
        return false;
    } 
    public void sortAndDisplay()
    {
        LLNode node = log;
        int[] numbers = new int[5];
        for(int i=0;i<5;i++)
        {
            numbers[i] = node.getInfo();
            node = node.getLink();
        }
        Arrays.sort(numbers);
        System.out.println("The sorted list is:");
        for(int i=0; i<numbers.length;i++)
        {
            System.out.println(numbers[i]);
        }
        
    }
}
