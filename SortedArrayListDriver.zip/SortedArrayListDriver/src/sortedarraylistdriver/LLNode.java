/*
 * Program:SortedArrayListDriver
 * This:LLNode.java
 * Date:2/27/2016
 * Author:Nicholas Johnston
 * Purpose:These nodes hold an information element and a refrence to the next 
           link in the list. 
 */
package sortedarraylistdriver;

public class LLNode 
{//======class memeber variables
    private int info;
    private int index;
    private LLNode link;
    
    
    //======constructors
    public LLNode(int info)
    {//constructor
        this.info = info;
        link = null; //this is the only node so far
    }
    //============================void setInfo()================================
    public void setInfo(int info)
    {
        //sets info string of this node
        this.info = info;
    }
    //===========================String getInfo()===============================
    public int getInfo()
    {
        return info;
    }
    //===========================void setLink()=================================
    public void setLink(LLNode link)
    {//this sets the link for the node
        this.link = link;
    }
    //========================LLStringNode getLink()============================
    public LLNode getLink()
    {
        return link;
    }
    public void setIndex(int index)
    {
        this.index = index;
    }
    public int getIndex()
    {
        return index;
    }
    
}
