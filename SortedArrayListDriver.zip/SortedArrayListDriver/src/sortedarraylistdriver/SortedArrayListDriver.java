/*
 * Program:SortedArrayListDriver
 * This:SortedArrayListDriver.java
 * Date:2/27/2016
 * Author:Nicholas Johnston
 * Purpose:To sort four integers in 
 */
package sortedarraylistdriver;
import java.util.Scanner;

public class SortedArrayListDriver 
{

    
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        IntegerLog myLog = new IntegerLog("List of Numbers");
        System.out.println("Please enter a list of five integers for this program to sort");
        for(int i = 0;i<5;i++)
        {
            System.out.println("Please enter integer number " + i);
            while(!scan.hasNextInt())
            {
                System.out.println("That's not an integer, please re-enter");
                scan.nextLine();
            }
            myLog.insert(scan.nextInt());
        }
        //System.out.println(myLog.toString());
        myLog.sortAndDisplay();
    }
    
}
