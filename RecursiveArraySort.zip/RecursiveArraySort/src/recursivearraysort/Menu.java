/*
 * Program:RecursiveArraySort
 * This:Menu.java
 * Date:3/11/2016
 * Author:Nicholas Johnston
 * Purpose:To handle interaction with a user and to sort the array class.
 */
package recursivearraysort;
import java.util.Scanner;
/**
 *
 * @author Nick
 */
public class Menu 
{
    Scanner scan = new Scanner(System.in);
    public void run()
    {//this is the menu
        int length;
        System.out.println("Please enter the number of integers in your array");
        while(!scan.hasNextInt())
        {
            System.out.println("Please input a valid integer");
            scan.nextLine();
        }
        length = scan.nextInt();
        int[] array = setArray(length);
        array = recursiveBubbleSort(array,array.length);
        //displayArray(array);
        System.out.println("The largest element in this array is " + array[array.length-1]);
        
    }
    
    public int[] setArray(int length)
    {//This returns an initilized array of type int, accepts the length
        //to be initialized
        System.out.println("You have chosen to create an array " + length
            + " elements long");
        int[] array = new int[length];
        
        for(int i=0;i<array.length; i++)
        {
            System.out.println("Choose an integer to insert at position " +i + " in the array.");
            while(!scan.hasNextInt())
            {
                System.out.println("Invlid input, please re-eneter an integer");
                scan.nextLine();
            }
            array[i] = scan.nextInt();
        }
        return array;
    }
    public int[] recursiveBubbleSort(int[] array, int n)
    {//sorts the array lowest to highest such that the highest element is always
        //at index array.length-1
        int index = 0;
        while(index < (n-1))
        {
            if(array[index]> array[index +1])
            {
                swap(array,array[index], array[index+1]);
            }
            index++;
            if(n > 1)
            {
                recursiveBubbleSort(array, n-1);
            }
        }
        return array;
    }
    public void swap(int[] array, int i, int j)
    {//swaps elements of the array when sorting
        int temporary = array[i];
        array[i] = array[j];
        array[j] = temporary;
    }
    public void displayArray(int[] array)
    {//displays the array for debuggin purposes
        for(int i =0;i<array.length;i++)
        {
            System.out.println(array[i]);
        }
    }
    
    
}
