/*
 * Program:RecursiveArraaySort
 * This:RecursiveArraySort.java
 * Date:3/11/2016
 * Author:Nicholas Johnston
 * Purpose:To sort numbers in an array using recursion
 */
package recursivearraysort;

/**
 *
 * @author Nick
 */
public class RecursiveArraySort 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Menu menu = new Menu();
        menu.run();
                
        // TODO code application logic here
    }
    
}
