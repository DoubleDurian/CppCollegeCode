/*
 * Project: Ranking Project
 * This: FileRanking.java
 * Date: 2/29/2016
 * Author: C.Mayo
 * Purpose: To obtain user input and output sorted list
 */
package ranking.project;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileRanking 
{
    RankLinkedList list = new RankLinkedList();
    Scanner input = new Scanner(System.in);
    String rankingName;
    
    public FileRanking()
    {       
        //constructor
    }
//============================== fileInput ==============================    
    public void fileInput()
    {
        String fileName;
        String inputLine;
        String inputName;
        double inputValue;
        System.out.print("\nName of new ranking: ");
        rankingName = input.next();
        
        System.out.print("\nName of file: ");
        fileName = input.next();
        File file = new File(fileName);
        try //checks for valid file
        {
            Scanner fileInput = new Scanner(file);
            while(fileInput.hasNextLine())
            {
                inputName = "";
                inputLine = fileInput.nextLine(); //takes line from file
                if(inputLine.contains(" "))
                {
                    //splits line at spaces
                    String inputs[] = inputLine.split(" "); 
                    //checks if last part of line is double
                    if(isDouble(inputs[inputs.length-1])) 
                    {
                        //combines all but last part of line into inputName
                        for(int arrayCounter = 0; arrayCounter < inputs.length-1;
                                arrayCounter++)
                        {
                            inputName = inputName + " " + inputs[arrayCounter];
                        }
                        //converts last part of line into double
                        inputValue = Double.parseDouble(inputs[inputs.length-1]);
                        list.add(inputValue, inputName);
                    }
                    else
                    {
                        System.out.println("Invalid file data");
                        break;
                    }
                }
                else
                {
                    System.out.println("Invalid file data");
                    break;
                }
            }
            selectSort();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("File not found");
        }
    }
//================================ userInput ===========================
    public void userInput()
    {
        int choice;
        double quantity;
        String inputName;
        boolean inputting = true;
        
        System.out.print("\nName of new ranking: ");
        rankingName = input.next();
        
        while(inputting)
        {
            do
            {
                System.out.println("\n======== Rank Menu ========");
                System.out.println("New Object:               1");
                System.out.println("Finish List:              2");
                System.out.print("Enter choice here: ");
                
                while(!input.hasNextInt())
                {
                    System.out.println("\nInvalid Input\n");
                    System.out.println("\n======== Rank Menu ========");
                    System.out.println("New Object:               1");
                    System.out.println("Finish List:              2");
                    System.out.print("Enter choice here: ");
                    input.next();
                }
                
                choice = input.nextInt();
                
                if(choice < 1 || choice > 2)
                {
                    System.out.println("\nInvalid Input\n");
                }
            }while(choice < 1 || choice > 2);
            
            switch(choice)
            {
                case 1:
                    System.out.print("\nObject Name: ");
                    inputName = input.next();
                    
                    System.out.print("Ranking Number: ");
                    while(!input.hasNextDouble())
                    {
                        System.out.println("\nInvalid Input\n");
                        System.out.print("Ranking Number: ");
                        input.next();
                    }
                    quantity = input.nextDouble();
                    list.add(quantity, inputName);
                    break;
                case 2:
                    inputting = false;
                    break;
                default:
                    System.out.println("User validation error");
                    break;
            }
        }
        selectSort();
    }
//============================== selectSort ============================   
    public void selectSort()
    {
        int choice;
        if(list.head != null)
        {
            do
            {
                System.out.println("\n======== List Menu ========");
                System.out.println("Sort Low to High:         1");
                System.out.println("Sort High to Low:         2");
                System.out.print("Enter choice here: ");

                while(!input.hasNextInt())
                {
                    System.out.println("\nInvalid Input\n");
                    System.out.println("\n======== List Menu ========");
                    System.out.println("Sort Low to High:         1");
                    System.out.println("Sort High to Low:         2");
                    System.out.print("Enter choice here: ");
                    input.next();
                }

                choice = input.nextInt();

                if(choice < 1 || choice > 2)
                {
                    System.out.println("\nInvalid Input\n");
                }
            }while(choice < 1 || choice > 2);

            switch(choice)
            {
                case 1:
                    list.sortListLow(list.head);
                    break;
                case 2:
                    list.sortListHigh(list.head);
                    break;
                default:
                    System.out.println("User validation error");
            }
            System.out.println("\n======== " + rankingName + " ========");
            printList(list.head);
            list.head = null;
        }
        else
        {
            System.out.println("\nThe list is empty");
        }
    }
//============================== isDouble ===============================    
    private boolean isDouble(String input)
    {
        try
        {
            Double.parseDouble(input);
            return true;
        }
        catch(NumberFormatException e)
        {
            return false;
        }
    }
//================================ printList ===========================   
    public static void printList(ListNode current) 
    {
        int rank = 1;
        if(current != null)
        {
            System.out.print(rank + " " +current.valueName + " " 
                    + current.value + "\n");
            rank++;
            while (current.next != null) 
            {
                System.out.print(rank + " " + current.next.valueName + " " 
                        + current.next.value + "\n");
                current = current.next;
                rank++;
            }
            System.out.println();
        }
    }
}
