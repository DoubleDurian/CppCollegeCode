/*
 * Project: Ranking Project
 * This: RankingProject.java
 * Date: 2/29/2016
 * Author: C.Mayo
 * Purpose: To instantiate nodes and their methods
 */
package ranking.project;

public class ListNode 
{
    double value;
    String valueName;
    ListNode next;

    ListNode(double value, String valueName) 
    {
        //constructor
        this.value = value;
        this.valueName = valueName;
        next = null;
    }
//============================ getNext =============================
    public ListNode getNext()
    {
        return next;
    }
//============================ setNext =============================
    public void setNext(ListNode nextValue)
    {
        next = nextValue;
    }
}
 

