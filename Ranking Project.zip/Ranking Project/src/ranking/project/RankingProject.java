/*
 * Project: Ranking Project
 * This: RankingProject.java
 * Date: 2/29/2016
 * Author: C.Mayo
 * Purpose: To create a sorted list of ranked objects
 */
package ranking.project;

import java.util.Scanner;

public class RankingProject 
{
//================================ main ================================
    public static void main(String[] args) 
    {
        int choice;
        boolean running = true;
        Scanner input = new Scanner(System.in);
        FileRanking ranking = new FileRanking();
        
        while(running)
        {
            do
            {
                System.out.println("\n======== Main Menu ========");
                System.out.println("File List Input:          1");
                System.out.println("User List Input:          2");
                System.out.println("Exit Program:             3");
                System.out.print("Enter choice here: ");

                while(!input.hasNextInt())
                {
                    System.out.println("\nInvalid Input\n");
                    System.out.println("\n======== Main Menu ========");
                    System.out.println("File List Input:          1");
                    System.out.println("User List Input:          2");
                    System.out.println("Exit Program:             3");
                    System.out.print("Enter choice here: ");
                    input.next();
                }

                choice = input.nextInt();

                if(choice < 1 || choice > 3)
                {
                    System.out.println("\nInvalid Input\n");
                }
            }while(choice < 1 || choice > 3);
            
            switch(choice)
            {
                case 1:
                    ranking.fileInput();
                    break;
                case 2:
                    ranking.userInput();
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("User validation error");
            }
        }       
    } 
}
