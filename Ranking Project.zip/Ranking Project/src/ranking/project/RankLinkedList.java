/*
 * Project: Ranking Project
 * This: RankingProject.java
 * Date: 2/29/2016
 * Author: C.Mayo
 * Purpose: To instantiate linked lists and their methods
 */
package ranking.project;

public class RankLinkedList 
{
    public ListNode head;
    
    public RankLinkedList()
    {
        //constructor
    }
//============================= add ====================================   
    public void add(double value, String valueName)
    {
        boolean copy = false;
        if (head == null) 
        {                
            head = new ListNode(value, valueName);
        }
        else
        {
            ListNode listTemp = new ListNode(value, valueName);
            ListNode listCurrent = head;

            if (listCurrent != null) 
            {   
                //finds end of list
                while(listCurrent.getNext() != null) 
                {
                    //checks for copy
                    if(listTemp.valueName.equals(listCurrent.valueName))
                    {
                        listCurrent.value += listTemp.value;
                        copy = true;
                    }
                    listCurrent = listCurrent.getNext();
                }
                //sets new list item at end of list
                if(!copy)
                {
                    listCurrent.setNext(listTemp);
                }
            }
        }
    }
//=========================== sortListLow ==============================   
    public void sortListLow(ListNode current) 
    {
        ListNode head = current;
        ListNode sortPointer = head;
        
        current = current.next;
        
        while(current != null)
        {
            sortPointer = head;
            while(sortPointer.next != current)
            {
                if(sortPointer.value > current.value)
                {
                    //switches values
                    double tempValue = current.value;
                    String tempName = current.valueName;
                    current.value = sortPointer.value;
                    current.valueName = sortPointer.valueName;
                    sortPointer.value = tempValue;
                    sortPointer.valueName = tempName;
                }
                else
                {
                    sortPointer = sortPointer.next;
                }
            }
            current = current.next;
        }
    }
//============================== sortListHigh ==========================    
    public void sortListHigh(ListNode current) 
    {
        ListNode head = current;
        ListNode sortPointer = head;
        
        current = current.next;
        
        while(current != null)
        {
            sortPointer = head;
            while(sortPointer.next != current)
            {
                if(sortPointer.value < current.value)
                {
                    //switches values
                    double tempValue = current.value;
                    String tempName = current.valueName;
                    current.value = sortPointer.value;
                    current.valueName = sortPointer.valueName;
                    sortPointer.value = tempValue;
                    sortPointer.valueName = tempName;
                }
                else
                {
                    sortPointer = sortPointer.next;
                }
            }
            current = current.next;
        }
    }
}
